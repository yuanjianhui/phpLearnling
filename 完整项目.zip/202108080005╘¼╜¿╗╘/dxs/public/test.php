<?php
echo  phpinfo();