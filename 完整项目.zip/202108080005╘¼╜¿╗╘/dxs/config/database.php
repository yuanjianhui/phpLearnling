<?php
return [
    'type' => 'mysql',
    'host' => 'localhost',
    'port' => '3306',
    'dbname' => 'dxs',
    'charset' => 'utf8',
    'user' => 'root',
    'pwd' => 'root',
    'prefix' => 'dxs_'
];