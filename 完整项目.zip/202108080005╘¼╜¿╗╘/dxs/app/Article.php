<?php
namespace App;

use myframe\Model;

class Article extends Model
{

}
