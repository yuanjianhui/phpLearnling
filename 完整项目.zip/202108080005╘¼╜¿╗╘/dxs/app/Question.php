<?php
namespace App;

use myframe\Model;

class Question extends Model
{

}
