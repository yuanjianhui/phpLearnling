<?php
namespace App;

use myframe\Model;

class Video extends Model
{
}
