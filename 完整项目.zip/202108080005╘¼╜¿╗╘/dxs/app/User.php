<?php
namespace App;

use myframe\Model;

class User extends Model
{

}
