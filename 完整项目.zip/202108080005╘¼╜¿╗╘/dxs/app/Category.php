<?php
namespace App;

use myframe\Model;

class Category extends Model
{
}
