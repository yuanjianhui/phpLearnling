<?php
namespace App;

use myframe\Model;

class Discuss extends Model
{

}
