<?php
/* Smarty version 4.1.0, created on 2022-06-16 19:11:30
  from 'D:\phpstudy_pro\WWW\dxs\resources\views\admin\article_discuss.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62ab0fe22e71d5_86499557',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f696ef737550eb097e3cc7ff0bb538e56b7e896a' => 
    array (
      0 => 'D:\\phpstudy_pro\\WWW\\dxs\\resources\\views\\admin\\article_discuss.html',
      1 => 1654498499,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62ab0fe22e71d5_86499557 (Smarty_Internal_Template $_smarty_tpl) {
?><div>
    <div class="main-title">
        <h2>文章评论区</h2>
    </div>
    <div class="main-section">
        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>标题</th>
                <th>作者</th>
                <th>时间</th>
                <th>内容</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($_smarty_tpl->tpl_vars['article']->value) {?>
            <tr>
                <td>
                    <a href="/admin/article/save?id=<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['v']->value['id'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
"><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['title'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</a>
                </td>
                <td><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['author'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</td>
                <td><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['created_at'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</td>
                <td><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['content'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</td>
            <?php } else { ?>
            <tr>
                <td colspan="3" class="text-center">列表为空</td>
            </tr>
            <?php }?>
            </tbody>
        </table>
    </div>
    <h3>评论区:</h3>
    <form method="post" action="/admin/discuss/save" class="j-form">
    <div><textarea class="j-content" name="content"  value=""   style="height:180px ;weight:18px"><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['data']->value['content'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</textarea></div>
        <div></div>
        <div></div>
        <div><input type="text" name="username" placeholder="请输入用户名" value=""></div>
        <input type="hidden" name="id" value="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['id'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
">
        <input type="submit" value="提交评论" class="btn btn-primary">
        <a href="/admin/article/shows" class="btn btn-default">返回列表</a>
    </form>
</div>
<?php echo '<script'; ?>
>
    main.menuActive('article');
    main.ajaxForm('.j-form', function () {
        main.content('/admin/discuss/save');
    });
    main.loadJS('/static/admin/editor/ueditor1.4.3.3/ueditor.config.js');
    main.loadJS('/static/admin/editor/ueditor1.4.3.3/ueditor.all.min.js');
    main.loadJS('/static/admin/editor/main.editor.js');
    main.editor($('.j-content'), 'article_edit', function(opt) {
        opt.UEDITOR_HOME_URL = '/static/admin/editor/ueditor1.4.3.3/'
    }, function(editor) {
        $('.j-form').submit(function() {
            //同步编辑器内容
            editor.sync();
        });
    });
<?php echo '</script'; ?>
>
<?php echo '</script'; ?>
><?php }
}
