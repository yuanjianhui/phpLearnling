<?php
/* Smarty version 4.1.0, created on 2022-04-23 13:04:38
  from 'D:\phpstudy_pro\WWW\cms\resources\views\edit_story.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_626388e6d64206_39680203',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '73d772765b1b817a3bb6794537b46c5cf261ce2d' => 
    array (
      0 => 'D:\\phpstudy_pro\\WWW\\cms\\resources\\views\\edit_story.html',
      1 => 1650690015,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_626388e6d64206_39680203 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        .box {
            width: 50%;
            margin: auto;
        }
        .box h3 {
            text-align: center;
        }
        form {
            /*text-align: center;*/
        }
        form div {
            margin-top: 15px;
        }
        form label {
            width: 40%;
            display: inline-block;
            text-align: right;
        }
        form .top {
            vertical-align: top;
        }
        form .button {
            text-align: center;
        }
        form .button input {
            padding: 5px 20px;
            background: #0052d9;
            color: #fff;
            border: 1px solid #fff;
        }
    </style>
</head>
<body>
<div class="box">
    <h3>编辑党史故事</h3>
    <div>
        <form action="/story/updateHandle" method="post">
            <div>
                <label for="title">标题：</label>
                <input type="text" name="title" id="title" value="<?php echo $_smarty_tpl->tpl_vars['story']->value['title'];?>
"/>
            </div>
            <div>
                <label for="author">作者：</label>
                <input type="text" name="author" id="author"value="<?php echo $_smarty_tpl->tpl_vars['story']->value['author'];?>
" />
            </div>
            <div>
                <label class="top" for="des">简介：</label>
                <textarea name="des" id="des" cols="30" rows="4"><?php echo $_smarty_tpl->tpl_vars['story']->value['des'];?>
</textarea>
            </div>
            <div>
                <label for="time">发布时间：</label>
                <input type="date" name="time" id="time" value= "<?php echo $_smarty_tpl->tpl_vars['story']->value['time'];?>
"/>
            </div>
            <div>
                <label class="top" for="content">内容：</label>
                <textarea name="content" id="content" cols="30" rows="10"><?php echo $_smarty_tpl->tpl_vars['story']->value['content'];?>
</textarea>
            </div>
            <div>
            <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['story']->value['id'];?>
">
            </div>
            <div class="button">
                <input type="submit" value="提交" />
            </div>
        </form>
    </div>
</div>
</body>
</html>
<?php }
}
