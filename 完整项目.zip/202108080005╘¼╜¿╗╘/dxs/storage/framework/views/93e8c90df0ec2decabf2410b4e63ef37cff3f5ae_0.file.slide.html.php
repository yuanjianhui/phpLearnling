<?php
/* Smarty version 4.1.0, created on 2022-05-15 22:38:32
  from 'D:\www\cms12\resources\views\test\slide.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628110689cfb89_10360364',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '93e8c90df0ec2decabf2410b4e63ef37cff3f5ae' => 
    array (
      0 => 'D:\\www\\cms12\\resources\\views\\test\\slide.html',
      1 => 1652581452,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628110689cfb89_10360364 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="slide">
    轮播图
</div><?php }
}
