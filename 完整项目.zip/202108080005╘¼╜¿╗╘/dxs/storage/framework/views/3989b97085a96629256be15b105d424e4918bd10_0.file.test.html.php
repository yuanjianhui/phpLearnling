<?php
/* Smarty version 4.1.0, created on 2022-04-22 23:10:30
  from 'D:\phpstudy_pro\WWW\cms\resources\views\test.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6262c5669f6c07_79579399',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3989b97085a96629256be15b105d424e4918bd10' => 
    array (
      0 => 'D:\\phpstudy_pro\\WWW\\cms\\resources\\views\\test.html',
      1 => 1650639619,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6262c5669f6c07_79579399 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>smarty</title>
</head>
<body>
    <h1>Hello <?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</h1>
    <p> <?php echo $_smarty_tpl->tpl_vars['desc']->value;?>
</p>
</body>
</html>
<?php }
}
