<?php
/* Smarty version 4.1.0, created on 2022-05-18 15:36:51
  from 'C:\phpstudy_pro\WWW\cms\resources\views\sub\slide.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6284a213cf5fb6_79282258',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd474b3b69260f724f467922946a97c06a5cce3cf' => 
    array (
      0 => 'C:\\phpstudy_pro\\WWW\\cms\\resources\\views\\sub\\slide.html',
      1 => 1574602960,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6284a213cf5fb6_79282258 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="slide">
  <div class="slide-wrap">
    <ul>
      <li><a href="#"><img src="/static/images/20.jpg"></a></li>
      <li><a href="#"><img src="/static/images/21.jpg"></a></li>
      <li><a href="#"><img src="/static/images/22.jpg"></a></li>
    </ul>
  </div>
  <ul class="slide-circle">
    <li class="on"></li><li></li><li></li>
  </ul>
</div><?php }
}
