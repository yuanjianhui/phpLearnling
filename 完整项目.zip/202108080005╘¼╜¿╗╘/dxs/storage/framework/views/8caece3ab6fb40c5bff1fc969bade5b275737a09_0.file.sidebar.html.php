<?php
/* Smarty version 4.1.0, created on 2022-05-17 08:23:11
  from 'D:\www\cms34\resources\views\test\sidebar.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6282eaefbd3588_70586744',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8caece3ab6fb40c5bff1fc969bade5b275737a09' => 
    array (
      0 => 'D:\\www\\cms34\\resources\\views\\test\\sidebar.html',
      1 => 1652581506,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6282eaefbd3588_70586744 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="sidebar">
    侧边栏
</div><?php }
}
