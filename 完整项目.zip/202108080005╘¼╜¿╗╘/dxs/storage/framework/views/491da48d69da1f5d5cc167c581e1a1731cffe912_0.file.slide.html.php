<?php
/* Smarty version 4.1.0, created on 2022-05-17 09:32:07
  from 'D:\www\cms34\resources\views\sub\slide.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6282fb17753003_04254657',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '491da48d69da1f5d5cc167c581e1a1731cffe912' => 
    array (
      0 => 'D:\\www\\cms34\\resources\\views\\sub\\slide.html',
      1 => 1574602960,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6282fb17753003_04254657 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="slide">
  <div class="slide-wrap">
    <ul>
      <li><a href="#"><img src="/static/images/20.jpg"></a></li>
      <li><a href="#"><img src="/static/images/21.jpg"></a></li>
      <li><a href="#"><img src="/static/images/22.jpg"></a></li>
    </ul>
  </div>
  <ul class="slide-circle">
    <li class="on"></li><li></li><li></li>
  </ul>
</div><?php }
}
