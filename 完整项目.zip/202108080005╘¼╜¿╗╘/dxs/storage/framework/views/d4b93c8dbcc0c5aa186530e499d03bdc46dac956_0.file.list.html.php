<?php
/* Smarty version 4.1.0, created on 2022-05-15 22:38:32
  from 'D:\www\cms12\resources\views\test\list.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628110689db700_72781577',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd4b93c8dbcc0c5aa186530e499d03bdc46dac956' => 
    array (
      0 => 'D:\\www\\cms12\\resources\\views\\test\\list.html',
      1 => 1652581432,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628110689db700_72781577 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="list">
    文章列表
</div><?php }
}
