<?php
/* Smarty version 4.1.0, created on 2022-05-23 17:52:07
  from 'D:\phpstudy_pro\WWW\cms\resources\views\sub\slide.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628b5947b617a9_18901751',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c3503a25988d7c86545f6bcc4145c5ab4c61530f' => 
    array (
      0 => 'D:\\phpstudy_pro\\WWW\\cms\\resources\\views\\sub\\slide.html',
      1 => 1574602960,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628b5947b617a9_18901751 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="slide">
  <div class="slide-wrap">
    <ul>
      <li><a href="#"><img src="/static/images/20.jpg"></a></li>
      <li><a href="#"><img src="/static/images/21.jpg"></a></li>
      <li><a href="#"><img src="/static/images/22.jpg"></a></li>
    </ul>
  </div>
  <ul class="slide-circle">
    <li class="on"></li><li></li><li></li>
  </ul>
</div><?php }
}
