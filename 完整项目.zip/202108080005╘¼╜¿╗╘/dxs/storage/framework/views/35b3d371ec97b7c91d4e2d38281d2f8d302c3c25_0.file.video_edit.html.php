<?php
/* Smarty version 4.1.0, created on 2022-06-16 17:59:00
  from 'D:\phpstudy_pro\WWW\dxs\resources\views\admin\video_edit.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62aafee42a0b03_00600931',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '35b3d371ec97b7c91d4e2d38281d2f8d302c3c25' => 
    array (
      0 => 'D:\\phpstudy_pro\\WWW\\dxs\\resources\\views\\admin\\video_edit.html',
      1 => 1654494273,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62aafee42a0b03_00600931 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="main-title">
    <h2><?php if ($_smarty_tpl->tpl_vars['id']->value) {?>修改<?php } else { ?>添加<?php }?>视频</h2>
</div>
<div class="main-section">
    <form method="post" action="/admin/video/save" class="j-form">
        <ul class="form-group form-inline">
            <li>
                <input type="text" class="form-control" name="title" value="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['data']->value['title'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
" required>
                <label>视频类型</label>
            </li>
            <li>
                <select name="cid" class="form-control" style="min-width:196px;">
                    <option value="0">---</option>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['category']->value, 'v');
$_smarty_tpl->tpl_vars['v']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
$_smarty_tpl->tpl_vars['v']->do_else = false;
?>
                    <option value="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['v']->value['id'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
" <?php if ($_smarty_tpl->tpl_vars['v']->value['id'] === $_smarty_tpl->tpl_vars['data']->value['cid']) {?>selected<?php }?>><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['v']->value['name'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
 </option>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </select>
                <label>所属分类</label>
            </li>
            <li>
                <input type="text" class="form-control" name="author" value="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['data']->value['author'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
" required>
                <label>作者</label>
            </li>
            <li>
                <label>视频</label>
                <input type="file" name="video">
            </li>
            <?php if ($_smarty_tpl->tpl_vars['data']->value['video']) {?>
            <li>
                <ul class="main-imglist">
                    <li>
                        <div class="main-imglist-item">
                            <a href="/uploads/video/<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['data']->value['video'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
" target="_blank"><video src="/uploads/video/<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['data']->value['video'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
" style="height: 120px;width: 120px"></video></a>
                        </div>
                    </li>
                </ul>
            </li>
            <?php }?>
            <li>
                <input type="hidden" name="id" value="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['id']->value, ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
">
                <input type="submit" value="提交表单" class="btn btn-primary">
                <a href="/admin/video/shows" class="btn btn-default">返回列表</a>
            </li>
        </ul>
    </form>
</div>
<?php echo '<script'; ?>
>
    main.menuActive('video');
    main.ajaxForm('.j-form', function () {
        main.content('/admin/video/shows');
    });
    main.loadJS('/static/admin/editor/ueditor1.4.3.3/ueditor.config.js');
    main.loadJS('/static/admin/editor/ueditor1.4.3.3/ueditor.all.min.js');
    main.loadJS('/static/admin/editor/main.editor.js');
    main.editor($('.j-content'), 'article_edit', function(opt) {
        opt.UEDITOR_HOME_URL = '/static/admin/editor/ueditor1.4.3.3/'
    }, function(editor) {
        $('.j-form').submit(function() {
            //同步编辑器内容
            editor.sync();
        });
    });
<?php echo '</script'; ?>
><?php }
}
