<?php
/* Smarty version 4.1.0, created on 2022-05-15 23:30:48
  from 'D:\www\cms12\resources\views\sub\slide.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62811ca8a50a09_05796656',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9b4671f7042217a9521033d07d584630d4356ccc' => 
    array (
      0 => 'D:\\www\\cms12\\resources\\views\\sub\\slide.html',
      1 => 1574602960,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62811ca8a50a09_05796656 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="slide">
  <div class="slide-wrap">
    <ul>
      <li><a href="#"><img src="/static/images/20.jpg"></a></li>
      <li><a href="#"><img src="/static/images/21.jpg"></a></li>
      <li><a href="#"><img src="/static/images/22.jpg"></a></li>
    </ul>
  </div>
  <ul class="slide-circle">
    <li class="on"></li><li></li><li></li>
  </ul>
</div><?php }
}
