<?php
/* Smarty version 4.1.0, created on 2022-05-15 22:38:32
  from 'D:\www\cms12\resources\views\test\sidebar.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628110689e7282_68208314',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '49e937ed11109bfeb7d7cff6f20cdaab6ca64021' => 
    array (
      0 => 'D:\\www\\cms12\\resources\\views\\test\\sidebar.html',
      1 => 1652581506,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628110689e7282_68208314 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="sidebar">
    侧边栏
</div><?php }
}
