<?php
/* Smarty version 4.1.0, created on 2022-05-17 08:23:11
  from 'D:\www\cms34\resources\views\test\slide.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_6282eaefb52701_61050081',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c79ee001a2a4f86f1ce0c350b60f1b2edea27a0f' => 
    array (
      0 => 'D:\\www\\cms34\\resources\\views\\test\\slide.html',
      1 => 1652581452,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6282eaefb52701_61050081 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="slide">
    轮播图
</div><?php }
}
