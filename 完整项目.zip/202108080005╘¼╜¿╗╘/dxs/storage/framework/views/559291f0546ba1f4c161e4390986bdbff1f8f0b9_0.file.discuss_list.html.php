<?php
/* Smarty version 4.1.0, created on 2022-06-16 18:48:22
  from 'D:\phpstudy_pro\WWW\dxs\resources\views\admin\discuss_list.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62ab0a769a4945_71272013',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '559291f0546ba1f4c161e4390986bdbff1f8f0b9' => 
    array (
      0 => 'D:\\phpstudy_pro\\WWW\\dxs\\resources\\views\\admin\\discuss_list.html',
      1 => 1654498499,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62ab0a769a4945_71272013 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="main-title">
    <h2>评论信息</h2>
</div>
<div class="main-section">
    <table class="table table-striped table-bordered table-hover">
        <thead>
        <tr>
            <th>标题</th>
            <th>作者</th>

            <th>用户名</th>
            <th>评论内容</th>
            <th>创建时间</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['title'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</td>
            <td><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['author'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</td>

            <td><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['user']->value, ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</td>
            <td><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['discuss']->value, ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</td>
            <td><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['created_at'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</td>
        </tr>
        </tbody>
    </table>
    <div class="text-center"><?php echo $_smarty_tpl->tpl_vars['page_html']->value;?>
</div>
</div>
<?php echo '<script'; ?>
>
    main.menuActive('discuss');
<?php echo '</script'; ?>
><?php }
}
