<?php
/* Smarty version 4.1.0, created on 2022-04-23 11:12:22
  from 'D:\phpstudy_pro\WWW\cms\resources\views\story_list.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62636e96f365e7_95762091',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cb695441ad621e8c0ba106f9fb5023dac08c3e93' => 
    array (
      0 => 'D:\\phpstudy_pro\\WWW\\cms\\resources\\views\\story_list.html',
      1 => 1650683540,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62636e96f365e7_95762091 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>红色党史故事</title>
    <style>
        .box {
            width: 50%;
            margin: auto;
        }
        h3 {
            text-align: center;
            color: #ff0000;
        }
        .head a {
            float: right;
            text-decoration: none;
            color: #0052d9;
        }
        .head a:hover {
            color: #0041a7;
            font-weight: bold;
        }
        table {
            margin: auto;
            border-collapse: collapse;
            width: 100%;
        }
        table, table td, table th {
            border: 1px solid #ff0000;
            padding: 10px 15px;
        }
        table th {
            background: #ff0000;
            color: #ffffff;
        }
    </style>
</head>
<body>
<div class="box">
    <div class="head">
        <h3>红色党史故事列表</h3>
        <a href="/story/add">添加党史故事</a>
    </div>
    <table>
        <tr>
            <th>标题</th>
            <th>作者</th>
            <th>简介</th>
            <th>发布时间</th>
            <th>操作</th>
        </tr>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['story']->value, 'item');
$_smarty_tpl->tpl_vars['item']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->do_else = false;
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['item']->value['author'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['item']->value['des'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['item']->value['time'];?>
</td>
                <td> <a href="/story/editHandle?id=<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
">编辑</a></td>
            </tr>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </table>
</div>
</body>
</html><?php }
}
