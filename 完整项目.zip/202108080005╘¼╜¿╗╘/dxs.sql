/*
Navicat MySQL Data Transfer

Source Server         : demo
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : dxs

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2022-06-17 18:04:31
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dxs_article
-- ----------------------------
DROP TABLE IF EXISTS `dxs_article`;
CREATE TABLE `dxs_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `author` varchar(15) NOT NULL DEFAULT '' COMMENT '作者',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '封面图',
  `show` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否发布',
  `views` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `content` text NOT NULL COMMENT '内容',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of dxs_article
-- ----------------------------
INSERT INTO `dxs_article` VALUES ('1', '1', '俄罗斯与乌克兰战争', '卢某', '', '1', '0', '<p>乌克兰与俄罗斯冲突原因主要是因为复杂的历史原因叠加地缘政治变化所致，所以俄罗斯和乌克兰的冲突成为战争。比两方面可以看出俄罗斯和乌克兰冲突的原因由来：</p><p>第一个方面是历史渊源。乌克兰和俄罗斯历史联系紧密。在冷战结束和苏联解体以后，乌克兰的主要政治领导人与俄罗斯相对来说维持着比较密切、一定程度上互相认可的合作关系。</p><p>第二个方面，是国际政治变化导致的结果。首先是跨大西洋及欧洲与俄罗斯存在一种结构性的矛盾，这包括俄罗斯和北约、俄罗斯和美国、俄罗斯和欧洲的结构性矛盾。目前来看，在美国的不断挑动刺激下双方陷入直接对抗的状况。</p><p><br /></p>', '2022-06-03 21:39:44');
INSERT INTO `dxs_article` VALUES ('2', '3', '2022NBA篮球总决赛', '刘某', '', '0', '0', '<p>中新社旧金山6月3日电 2021-2022赛季美职篮总决赛首场比赛2日在旧金山大通中心进行，波士顿凯尔特人队客场120：108逆转金州勇士队，在7战4胜的系列赛中取得开门红。</p><p>整场比赛，凯尔特人三分球41投21中，命中率高达51.2%，而勇士45投19中，命中率为42.2%。两队上半场共投出20个三分球，创造了NBA总决赛上半场3分球数量的新纪录。另外，库里首节投进6个三分球，创下NBA总决赛单个球员单节比赛的三分球最高纪录。</p><p>此役，勇士本赛季季后赛主场不败的纪录被打破。双方的总决赛第二场比赛将于6月5日在旧金山大通中心举行。</p>', '2022-06-03 21:44:41');
INSERT INTO `dxs_article` VALUES ('3', '4', '诗意鉴赏', '王维', '', '0', '0', '<p>诗词《红豆》</p><p>红豆生南国，春来发几枝。</p><p>愿君多采撷，此物最相思。</p><p>诗人主要是借生于南国的红豆,表达了对友人的眷念之情.</p><p><br /></p><p><br /></p>', '2022-06-03 21:50:49');
INSERT INTO `dxs_article` VALUES ('4', '2', '现役主流显卡', '沈某', '', '0', '0', '<p>大家选择显卡的时候，不要盲目选贵，也不要看价格低就着急入手，一定要按自己的预算和需求去选购适合自己的类型款式，今天在这里也为大家准备了几款最值得入手的显卡型号，</p><p>华硕TUF RTX3060 电竞游戏专业独立显卡</p><p>七彩虹RTX 3060 游戏电脑独立显卡</p><p>七彩虹iGame RTX 3060Ti 游戏显卡 白色</p><p>华硕TUF RTX3070TI 游戏独立显卡 </p><p><br /></p>', '2022-06-03 21:55:34');
INSERT INTO `dxs_article` VALUES ('5', '5', '网络安全', '夏某', '', '0', '0', '<p>《中华人民共和国网络安全法》是为保障网络安全，维护网络空间主权和国家安全、社会公共利益，保护公民、法人和其他组织的合法权益，促进经济社会信息化健康发展而制定的法律。主要包括总则，网络安全支持与促进、网络运营安全、网络信息安全、监测预警与应急处置、法律责任、附则等。 </p>', '2022-06-03 21:57:31');
INSERT INTO `dxs_article` VALUES ('8', '2', '小华', 'jjjj', '', '1', '0', '<p>不再见</p>', '2022-06-16 19:24:45');

-- ----------------------------
-- Table structure for dxs_category
-- ----------------------------
DROP TABLE IF EXISTS `dxs_category`;
CREATE TABLE `dxs_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL COMMENT '名称',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of dxs_category
-- ----------------------------
INSERT INTO `dxs_category` VALUES ('1', '新闻', '0');
INSERT INTO `dxs_category` VALUES ('2', '科技', '1');
INSERT INTO `dxs_category` VALUES ('3', '体育', '2');
INSERT INTO `dxs_category` VALUES ('4', '文化', '3');
INSERT INTO `dxs_category` VALUES ('5', '网络', '4');

-- ----------------------------
-- Table structure for dxs_discuss
-- ----------------------------
DROP TABLE IF EXISTS `dxs_discuss`;
CREATE TABLE `dxs_discuss` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `author` varchar(15) NOT NULL DEFAULT '' COMMENT '作者',
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '用户名',
  `content` text NOT NULL COMMENT '评论内容',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '评论时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of dxs_discuss
-- ----------------------------
INSERT INTO `dxs_discuss` VALUES ('1', '体育', '小明', '张三', '我同意', '2022-06-08 23:08:55');

-- ----------------------------
-- Table structure for dxs_question
-- ----------------------------
DROP TABLE IF EXISTS `dxs_question`;
CREATE TABLE `dxs_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `author` varchar(15) NOT NULL DEFAULT '' COMMENT '作者',
  `show` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否发布',
  `views` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `content` text NOT NULL COMMENT '内容',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of dxs_question
-- ----------------------------
INSERT INTO `dxs_question` VALUES ('2', '4', '无穷级数', '卢谋', '1', '6', '<p>关于泰勒公式，我们应该如何运用？</p>', '2022-06-02 19:01:12');
INSERT INTO `dxs_question` VALUES ('3', '1', '热点新闻', '沈某', '1', '4', '<p>关于网上的新闻都是真实的吗？有什么看法？</p>', '2022-06-02 19:03:31');
INSERT INTO `dxs_question` VALUES ('4', '2', '手机处理器', '夏某', '1', '5', '<p>现在主流的手机处理器有哪些?</p>', '2022-06-02 19:06:02');
INSERT INTO `dxs_question` VALUES ('5', '4', '文言文学习', '王某', '0', '9', '<p>如何更好的学习古时的文言文？有什么好的方法？</p>', '2022-06-02 19:07:08');
INSERT INTO `dxs_question` VALUES ('6', '5', '网速优化', '李某', '0', '1', '<p>如何优化电脑上的网速问题，路由器是问题之一吗？</p>', '2022-06-02 19:10:39');
INSERT INTO `dxs_question` VALUES ('7', '3', '篮球运动', '张三', '0', '1', '<p>有人可以分享一下关于篮球的小技巧吗？</p>', '2022-06-05 19:12:01');
INSERT INTO `dxs_question` VALUES ('8', '2', '人工智能', '一个小虎牙', '1', '0', '<p>关于人工智能的发展你有什么看法？</p>', '2022-06-05 19:13:24');
INSERT INTO `dxs_question` VALUES ('9', '4', '语文', '张三', '1', '0', '<p>如何学好语文这门课</p>', '2022-06-17 12:14:33');

-- ----------------------------
-- Table structure for dxs_tag
-- ----------------------------
DROP TABLE IF EXISTS `dxs_tag`;
CREATE TABLE `dxs_tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '标签名称',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '显示状态0显示1不显示',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dxs_tag
-- ----------------------------
INSERT INTO `dxs_tag` VALUES ('1', 'PHP', '0', '0');
INSERT INTO `dxs_tag` VALUES ('2', 'JAVA', '1', '0');
INSERT INTO `dxs_tag` VALUES ('3', 'Python', '2', '0');
INSERT INTO `dxs_tag` VALUES ('4', 'MySQL', '3', '0');
INSERT INTO `dxs_tag` VALUES ('5', 'C++', '4', '0');

-- ----------------------------
-- Table structure for dxs_user
-- ----------------------------
DROP TABLE IF EXISTS `dxs_user`;
CREATE TABLE `dxs_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` char(32) NOT NULL DEFAULT '' COMMENT '密码',
  `salt` char(32) NOT NULL DEFAULT '' COMMENT '密码salt',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of dxs_user
-- ----------------------------
INSERT INTO `dxs_user` VALUES ('1', 'admin', 'feddbf1b144d0ac8b34604db019d5a50', 'salt');
INSERT INTO `dxs_user` VALUES ('2', 'user_1', 'feddbf1b144d0ac8b34604db019d5a50', 'salt');
INSERT INTO `dxs_user` VALUES ('3', 'user_2', 'feddbf1b144d0ac8b34604db019d5a50', 'salt');

-- ----------------------------
-- Table structure for dxs_video
-- ----------------------------
DROP TABLE IF EXISTS `dxs_video`;
CREATE TABLE `dxs_video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `author` varchar(15) NOT NULL DEFAULT '' COMMENT '作者',
  `video` varchar(255) NOT NULL DEFAULT '' COMMENT '视频',
  `show` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否发布',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of dxs_video
-- ----------------------------
INSERT INTO `dxs_video` VALUES ('2', '3', '篮球', '刘某', '', '0', '2022-06-05 21:44:36');
INSERT INTO `dxs_video` VALUES ('3', '2', '生活', '夏某', '', '0', '2022-06-05 21:53:22');
INSERT INTO `dxs_video` VALUES ('8', '3', '篮球', '刘某', '2022-06/06/40a4fa0dbadd084b8fcec7d12210e17c.mp4', '0', '2022-06-06 15:26:34');
INSERT INTO `dxs_video` VALUES ('5', '4', '文言文', '沈某', '2022-06/06/587f77650d26139231c0910d923a3373.mp4', '0', '2022-06-05 21:55:04');
INSERT INTO `dxs_video` VALUES ('6', '3', '足球', '夏某', '2022-06/06/8933f4efc1593fda39a021dd43ca8886.mp4', '0', '2022-06-05 22:05:20');
INSERT INTO `dxs_video` VALUES ('7', '3', '篮球', '袁某', '2022-06/06/a2f3530a5dff4121ded8673996280003.mp4', '0', '2022-06-06 13:55:21');
INSERT INTO `dxs_video` VALUES ('9', '3', '篮球', '小红', '2022-06/17/5f2d05750555ef7740bb8991e95db1e6.mp4', '0', '2022-06-17 09:54:28');
